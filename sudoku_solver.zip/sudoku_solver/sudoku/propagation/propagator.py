# sudoku/propagation/propagator.py

from dataclasses import dataclass
from typing import List, Tuple
from ..model.grid import Grid
from ..layers.layer_manager import LayerManager
from ..visual.visual_hooks import VisualHooks


class Contradiction(Exception):
    pass


@dataclass
class ForcedMove:
    row: int
    col: int
    digit: int


class Propagator:
    """
    Handles logical propagation on layers:
    - rebuild layers
    - find forced moves
    - apply them
    - detect contradictions
    """

    def __init__(self, grid: Grid, layers: LayerManager, visual: VisualHooks):
        self.grid = grid
        self.layers = layers
        self.visual = visual

    def rebuild_all_layers(self) -> None:
        self.layers.rebuild_all_layers()

    def run_propagation(self) -> None:
        """
        Repeatedly apply forced moves until no more exist or a contradiction is found.
        """
        while True:
            forced = self.find_forced_moves()
            if not forced:
                self.check_for_contradictions()
                return
            self.apply_forced_moves(forced)
            self.check_for_contradictions()

    def find_forced_moves(self) -> List[ForcedMove]:
        """
        Find forced moves with prioritization and short-circuiting.
        1. Naked Singles (cell-level): Cheapest to find.
        2. Hidden Singles (unit-level): Row, then Col, then Box.
        Returns as soon as a category of moves is found.
        """
        forced: List[ForcedMove] = []
        N = self.grid.size
        digits = self.layers.digits

        # 1. Naked Singles (Cell-level)
        for r, c in self.grid.iter_cells():
            if not self.grid.is_empty(r, c):
                continue
            allowed = self.layers.allowed_digits_at(r, c)
            if len(allowed) == 1:
                forced.append(ForcedMove(r, c, allowed[0]))
        
        if forced:
            return forced

        # 2. Hidden Singles (Unit-level) - Row
        for d in digits:
            layer = self.layers.layers[d - 1]
            for r in range(N):
                cells = [(r, c) for c in range(N) if layer[r][c] and self.grid.is_empty(r, c)]
                if len(cells) == 1:
                    rr, cc = cells[0]
                    forced.append(ForcedMove(rr, cc, d))
            if forced:
                return self._deduplicate(forced)

        # 3. Hidden Singles (Unit-level) - Column
        for d in digits:
            layer = self.layers.layers[d - 1]
            for c in range(N):
                cells = [(r, c) for r in range(N) if layer[r][c] and self.grid.is_empty(r, c)]
                if len(cells) == 1:
                    rr, cc = cells[0]
                    forced.append(ForcedMove(rr, cc, d))
            if forced:
                return self._deduplicate(forced)

        # 4. Hidden Singles (Unit-level) - Box
        box_size = self.grid.box_size
        for d in digits:
            layer = self.layers.layers[d - 1]
            for br in range(0, N, box_size):
                for bc in range(0, N, box_size):
                    cells = []
                    for dr in range(box_size):
                        for dc in range(box_size):
                            rr, cc = br + dr, bc + dc
                            if layer[rr][cc] and self.grid.is_empty(rr, cc):
                                cells.append((rr, cc))
                    if len(cells) == 1:
                        rr, cc = cells[0]
                        forced.append(ForcedMove(rr, cc, d))
            if forced:
                return self._deduplicate(forced)

        return []

    def _deduplicate(self, forced: List[ForcedMove]) -> List[ForcedMove]:
        unique = {}
        for mv in forced:
            unique[(mv.row, mv.col)] = mv
        return list(unique.values())

    def apply_forced_moves(self, moves: List[ForcedMove]) -> None:
        for mv in moves:
            if not self.grid.is_empty(mv.row, mv.col):
                continue
            self.grid.set(mv.row, mv.col, mv.digit)
            self.visual.mark_forced(mv.row, mv.col, mv.digit)
        self.layers.rebuild_all_layers()

    def check_for_contradictions(self) -> None:
        N = self.grid.size
        digits = self.layers.digits

        # Any empty cell with no allowed digits?
        for r, c in self.grid.iter_cells():
            if self.grid.is_empty(r, c):
                allowed = self.layers.allowed_digits_at(r, c)
                if len(allowed) == 0:
                    self.visual.mark_contradiction_cell(r, c)
                    raise Contradiction("Cell has no allowed digits.")

        # Any digit with no place in a unit?
        for d in digits:
            layer = self.layers.layers[d - 1]

            # Rows
            for r in range(N):
                cells = [(r, c) for c in range(N) if layer[r][c]]
                if len(cells) == 0:
                    raise Contradiction(f"Digit {d} has no place in row {r}.")

            # Columns
            for c in range(N):
                cells = [(r, c) for r in range(N) if layer[r][c]]
                if len(cells) == 0:
                    raise Contradiction(f"Digit {d} has no place in column {c}.")

            # Boxes
            box_size = self.grid.box_size
            for br in range(0, N, box_size):
                for bc in range(0, N, box_size):
                    cells = []
                    for dr in range(box_size):
                        for dc in range(box_size):
                            rr = br + dr
                            cc = bc + dc
                            if layer[rr][cc]:
                                cells.append((rr, cc))
                    if len(cells) == 0:
                        raise Contradiction(f"Digit {d} has no place in a box.")

    