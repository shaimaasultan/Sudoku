# sudoku/layers/layer_manager.py

from typing import List, Tuple
from ..model.grid import Grid


class LayerManager:
    """
    Manages one boolean layer per digit.
    layers[d][r][c] == True means digit (d+1) is allowed at (r,c).
    Digits are 1..N, but we store them 0..N-1 internally.
    """

    def __init__(self, grid: Grid):
        self.grid = grid
        self.size = grid.size
        self.digits = list(range(1, self.size + 1))
        self.layers: List[List[List[bool]]] = [
            [[True for _ in range(self.size)] for _ in range(self.size)]
            for _ in self.digits
        ]

    def clone(self, grid: Grid = None) -> "LayerManager":
        new_grid = grid if grid is not None else self.grid.clone()
        clone = LayerManager(new_grid)
        clone.layers = [
            [row[:] for row in layer]
            for layer in self.layers
        ]
        return clone

    def rebuild_all_layers(self, preserve_manual_forbids: bool = True) -> None:
        """
        Rebuild all layers from the current grid values.
        If preserve_manual_forbids is True, it keeps current False bits 
        (preserving manual forbids from backtracking).
        """
        N = self.size
        old_layers = self.layers if preserve_manual_forbids else None

        self.layers = [
            [[True for _ in range(N)] for _ in range(N)]
            for _ in self.digits
        ]

        # 1. Grid-based constraints: if (r,c) is set to v, then:
        #    - (r,c) can only be digit v
        #    - digit v cannot be anywhere else in row r, col c, or box(r,c)
        for r, c in self.grid.iter_cells():
            v = self.grid.get(r, c)
            if v == 0:
                continue
            
            # (r,c) can ONLY be v
            for d in self.digits:
                if d != v:
                    self.layers[d - 1][r][c] = False

            # v cannot be elsewhere in the same units
            for rr, cc in self.grid.row_indices(r):
                if (rr, cc) != (r, c):
                    self.layers[v - 1][rr][cc] = False
            for rr, cc in self.grid.col_indices(c):
                if (rr, cc) != (r, c):
                    self.layers[v - 1][rr][cc] = False
            for rr, cc in self.grid.box_indices(r, c):
                if (rr, cc) != (r, c):
                    self.layers[v - 1][rr][cc] = False

        # 2. Re-apply manual forbids if requested
        if old_layers:
            for d_idx in range(len(self.digits)):
                for r in range(N):
                    for c in range(N):
                        if not old_layers[d_idx][r][c]:
                            self.layers[d_idx][r][c] = False

    def allowed_digits_at(self, r: int, c: int) -> List[int]:
        if not self.grid.is_empty(r, c):
            return []
        return [
            d for d in self.digits
            if self.layers[d - 1][r][c]
        ]

    def count_candidates_for_digit(self, d: int) -> int:
        layer = self.layers[d - 1]
        return sum(1 for r in range(self.size) for c in range(self.size) if layer[r][c])

    def units_for_digit(self, d: int) -> Tuple[int, int, int]:
        """
        Returns counts of units (rows, cols, boxes) where digit d has exactly 2 candidates.
        """
        layer = self.layers[d - 1]
        N = self.size
        box_size = self.grid.box_size

        def count_units(get_indices):
            cnt = 0
            for u in range(N):
                cells = get_indices(u)
                k = sum(1 for (r, c) in cells if layer[r][c])
                if k == 2:
                    cnt += 1
            return cnt

        rows_two = count_units(lambda r: self.grid.row_indices(r))
        cols_two = count_units(lambda c: self.grid.col_indices(c))

        def box_indices_flat(b):
            br = (b // box_size) * box_size
            bc = (b % box_size) * box_size
            return [
                (br + dr, bc + dc)
                for dr in range(box_size)
                for dc in range(box_size)
            ]

        boxes_two = count_units(box_indices_flat)
        return rows_two, cols_two, boxes_two

    def spatial_concentration(self, d: int) -> int:
        """
        Rough measure: number of distinct rows + cols + boxes used by digit d.
        Lower is more concentrated.
        """
        layer = self.layers[d - 1]
        N = self.size
        box_size = self.grid.box_size

        rows = set()
        cols = set()
        boxes = set()

        for r in range(N):
            for c in range(N):
                if layer[r][c]:
                    rows.add(r)
                    cols.add(c)
                    b = (r // box_size) * box_size + (c // box_size)
                    boxes.add(b)

        return len(rows) + len(cols) + len(boxes)

    def forbid_choice(self, d: int, r: int, c: int) -> None:
        self.layers[d - 1][r][c] = False
