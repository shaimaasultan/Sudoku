# sudoku/solver.py

from .model.grid import Grid
from .layers.layer_manager import LayerManager
from .propagation.propagator import Propagator, Contradiction
from .branching.branching_engine import BranchingEngine, SearchRestart
from .visual.visual_hooks import VisualHooks


class SudokuSolver:
    """
    High-level orchestrator:
    - builds grid and layers
    - runs propagation
    - then branching
    """

    def __init__(self, size: int = 9, visual: VisualHooks | None = None):
        self.size = size
        self.visual = visual or VisualHooks()

    def solve(self, values) -> Grid | None:
        grid = Grid(self.size, values)
        layers = LayerManager(grid)
        propagator = Propagator(grid, layers, self.visual)
        self.branching_engine = BranchingEngine(grid, layers, propagator, self.visual)

        # Initial propagation
        layers.rebuild_all_layers()
        try:
            propagator.run_propagation()
        except Contradiction:
            return None

        # Branching search with restarts
        max_restarts = 5
        for attempt in range(max_restarts):
            try:
                ok = self.branching_engine.solve_with_branching()
                if not ok:
                    return None
                break # Success
            except SearchRestart:
                # Re-init engine components to restart fresh with new random seeds
                print(f"Restarting search (attempt {attempt + 1})...")
                grid = Grid(self.size, values)
                layers = LayerManager(grid)
                propagator = Propagator(grid, layers, self.visual)
                self.branching_engine = BranchingEngine(grid, layers, propagator, self.visual)
                layers.rebuild_all_layers()
                propagator.run_propagation()
        else:
            # Exhausted all restarts
            return None

        if not self.branching_engine.is_solved():
            return None

        return self.branching_engine.grid

    def backtrack_and_continue(self):
        """
        Called when the current branch reports 'no solution'.
        Attempts to backtrack to the previous decision point and continue.
        Returns a solution grid or None if the entire search space is exhausted.
        """
        try:
            return self.branching_engine.backtrack_and_continue()
        except Exception:
            return None
