import random
from typing import Tuple
from ..model.grid import Grid
from ..model.state_stack import StateStack
from ..layers.layer_manager import LayerManager
from ..propagation.propagator import Propagator, Contradiction
from ..visual.visual_hooks import VisualHooks


class SearchRestart(Exception):
    """Raised when search should be restarted with a new random seed."""
    pass


class BranchingEngine:
    """
    Branching strategy:
      - primary: digit-based branching (choose digit, then cell)
      - fallback: cell-based branching (MRV on cells)
    Search is fully recursive: every guess continues with solve_with_branching().
    """

    def __init__(
        self,
        grid: Grid,
        layers: LayerManager,
        propagator: Propagator,
        visual: VisualHooks,
    ):
        self.grid = grid
        self.layers = layers
        self.propagator = propagator
        self.visual = visual
        self.state_stack = StateStack()
        self.nodes_visited = 0
        self.restart_threshold = (grid.size ** 2) * 2  # Adaptive threshold

    # ------------------------------------------------------------------ #
    # Top-level search
    # ------------------------------------------------------------------ #

    def solve_with_branching(self) -> bool:
        """
        Recursive search entry.
        Assumes propagation has already been run at the current node.
        Returns True if solved, False if unsolvable from this state.
        """
        if self.is_solved():
            return True

        try:
            # --- primary: digit-based branching ---
            d = self.choose_digit_for_branch()

            if d is not None:
                # digit-based: choose a cell for this digit
                r, c = self.choose_cell_for_digit(d)
                self.visual.mark_digit_branch(d, r, c)
            else:
                # --- fallback: cell-based branching ---
                r, c = self.choose_cell_fallback()
                allowed = self.layers.allowed_digits_at(r, c)
                d = next(iter(allowed))
                self.visual.mark_cell_fallback(r, c, allowed)

        except RuntimeError:
            # e.g. "No candidate cell found for digit." -> fallback
            r, c = self.choose_cell_fallback()
            allowed = self.layers.allowed_digits_at(r, c)
            d = next(iter(allowed))
            self.visual.mark_cell_fallback(r, c, allowed)

        except Contradiction:
            return False

        # One branching step: try this guess and recurse
        self.nodes_visited += 1
        if self.nodes_visited > self.restart_threshold:
            raise SearchRestart("Search depth threshold exceeded. Restarting...")

        return self.try_guess(d, r, c)

    def is_solved(self) -> bool:
        for r, c in self.grid.iter_cells():
            if self.grid.is_empty(r, c):
                return False
        return True

    # ------------------------------------------------------------------ #
    # Digit-based branching
    # ------------------------------------------------------------------ #

    def choose_digit_for_branch(self) -> int | None:
        """
        Choose a digit to branch on:
          - minimize candidate count
          - tie-break by "almost forced" units and spatial concentration
        Returns None if no digit is suitable (then we use cell-fallback).
        """
        digits = self.layers.digits
        best = None

        for d in digits:
            cand_count = self.layers.count_candidates_for_digit(d)
            if cand_count == 0:
                # contradiction will be handled elsewhere
                continue

            rows_two, cols_two, boxes_two = self.layers.units_for_digit(d)
            almost_forced = rows_two + cols_two + boxes_two
            concentration = self.layers.spatial_concentration(d)

            # Add random tie-breaker to prevent deterministic "stuckness"
            key = (cand_count, -almost_forced, concentration, random.random(), d)
            if best is None or key < best[0]:
                best = (key, d)

        return None if best is None else best[1]

    def choose_cell_for_digit(self, d: int) -> Tuple[int, int]:
        """
        Given a digit d, choose a cell where d is allowed.
        Heuristic:
          - prefer cells with fewer total allowed digits (MRV)
          - tie-break by overlap with same digit
        """
        N = self.grid.size
        layer = self.layers.layers[d - 1]

        best = None

        for r in range(N):
            for c in range(N):
                if not layer[r][c]:
                    continue
                if not self.grid.is_empty(r, c):
                    continue

                total_digits = len(self.layers.allowed_digits_at(r, c))
                overlap = self._overlap_with_same_digit(layer, r, c)
                # Random tie-breaker for cell selection
                key = (total_digits, -overlap, random.random(), r, c)

                if best is None or key < best[0]:
                    best = (key, (r, c))

        if best is None:
            raise RuntimeError("No candidate cell found for digit.")

        return best[1]

    def _overlap_with_same_digit(self, layer, r: int, c: int) -> int:
        """
        Count how many other candidates for this digit share row/col/box.
        """
        N = self.grid.size
        box_size = self.grid.box_size

        count = 0
        # Row
        for cc in range(N):
            if cc != c and layer[r][cc]:
                count += 1
        # Col
        for rr in range(N):
            if rr != r and layer[rr][c]:
                count += 1
        # Box
        br = (r // box_size) * box_size
        bc = (c // box_size) * box_size
        for dr in range(box_size):
            for dc in range(box_size):
                rr = br + dr
                cc = bc + dc
                if (rr, cc) != (r, c) and layer[rr][cc]:
                    count += 1
        return count

    # ------------------------------------------------------------------ #
    # Cell-based fallback branching (MRV on cells)
    # ------------------------------------------------------------------ #

    def choose_cell_fallback(self) -> Tuple[int, int]:
        """
        Fallback branching:
          - choose the empty cell with the fewest allowed digits (MRV).
        This is the "each empty cell has 2 options, pick one and try" logic.
        """
        best_cell: Tuple[int, int] | None = None
        best_domain_size: int | None = None

        for r, c in self.grid.iter_cells():
            if not self.grid.is_empty(r, c):
                continue

            allowed = self.layers.allowed_digits_at(r, c)
            if len(allowed) == 0:
                raise Contradiction("Cell has no allowed digits.")

            # Random tie-breaker for MRV fallback
            key = (len(allowed), random.random())
            if best_domain_size is None or key < (best_domain_size, 0):
                best_cell = (r, c)
                best_domain_size = len(allowed)

        if best_cell is None:
            raise RuntimeError("Fallback branching found no empty cell.")

        return best_cell

    # ------------------------------------------------------------------ #
    # Guessing + recursive backtracking
    # ------------------------------------------------------------------ #

    def try_guess(self, d: int, r: int, c: int) -> bool:
        """
        Try setting (r,c) = d, propagate, and recurse.
        On contradiction OR recursive failure:
          - restore state
          - forbid (d,r,c)
          - propagate
          - recurse again from the updated state
        """
        # Save state
        new_grid = self.grid.clone()
        state = {
            "grid": new_grid,
            "layers": self.layers.clone(new_grid),
        }
        self.state_stack.push(state)

        # Visual guess
        self.visual.mark_guess(r, c, d)

        # Apply guess
        self.grid.set(r, c, d)
        self.layers.rebuild_all_layers()

        success = False
        try:
            self.propagator.run_propagation()
            if self.is_solved():
                success = True
            else:
                success = self.solve_with_branching()
        except Contradiction:
            success = False

        if success:
            return True

        # --- Failure: backtrack and forbid ---
        prev = self.state_stack.pop()
        self.grid = prev["grid"]
        self.layers = prev["layers"]
        self.propagator.grid = self.grid
        self.propagator.layers = self.layers

        # Forbid this choice and propagate again
        self.layers.forbid_choice(d, r, c)
        self.layers.rebuild_all_layers()
        try:
            self.propagator.run_propagation()
        except Contradiction:
            # even after forbidding, no solution from here
            return False

        # After forbidding, continue search recursively
        if self.is_solved():
            return True
        return self.solve_with_branching()


    def backtrack_and_continue(self) -> bool:
        """
        Resume search by backtracking one level and continuing branching.
        Returns True if a solution is found, False if no more branches exist.
        """
        if self.state_stack.is_empty():
            # No more decisions to undo → truly unsolvable
            return False

        # Restore previous state
        prev = self.state_stack.pop()
        self.grid = prev["grid"]
        self.layers = prev["layers"]
        self.propagator.grid = self.grid
        self.propagator.layers = self.layers
        
        # Ensure branching engine's components are synced to the current grid
        self.layers.grid = self.grid
        self.propagator.grid = self.grid

        # Continue solving from this restored state
        try:
            self.propagator.run_propagation()
        except Contradiction:
            # This branch is dead too → recurse upward
            return self.backtrack_and_continue()

        return self.solve_with_branching()
